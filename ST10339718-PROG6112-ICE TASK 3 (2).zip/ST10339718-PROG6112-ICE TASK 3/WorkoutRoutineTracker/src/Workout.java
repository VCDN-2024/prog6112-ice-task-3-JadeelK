public abstract class Workout {
    private String exercises;
    private int duration;
    private int intensityLevel;

    public Workout(String exercises, int duration, int intensityLevel) {
        this.exercises = exercises;
        this.duration = duration;
        this.intensityLevel = intensityLevel;
    }

    public String getExercises() {
        return exercises;
    }

    public int getDuration() {
        return duration;
    }

    public int getIntensityLevel() {
        return intensityLevel;
    }
}
