public interface IWorkout {
    void printWorkout();
}
