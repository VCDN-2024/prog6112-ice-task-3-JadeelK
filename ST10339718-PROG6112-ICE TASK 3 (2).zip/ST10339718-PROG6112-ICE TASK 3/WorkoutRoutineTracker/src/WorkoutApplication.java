import java.util.Scanner;

public class WorkoutApplication {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the exercises: ");
        String exercises = scanner.nextLine();

        System.out.print("Enter the duration (in minutes): ");
        int duration = scanner.nextInt();

        System.out.print("Enter the intensity level (1 to 10): ");
        int intensityLevel = scanner.nextInt();

        ProcessWorkout workout = new ProcessWorkout(exercises, duration, intensityLevel);

        workout.printWorkout();

        scanner.close();
    }
}

